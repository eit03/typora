#include <Windows.h>
#include <assert.h>
#include "resource.h"


LRESULT CALLBACK MyWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPSTR lpCmdLine, _In_ int nShowCmd)
{
	//0.Design window class
	WNDCLASSW wc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hbrBackground = (HBRUSH)GetStockObject(LTGRAY_BRUSH);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wc.hInstance = hInstance;
	wc.lpfnWndProc = (WNDPROC)MyWndProc;
	wc.lpszClassName = L"CN_CLASSNAME";
	wc.lpszMenuName = 0;
	wc.style = 0;

	//1.Register window class
	BOOL bRes = GetClassInfoW(hInstance, wc.lpszClassName, &wc);
	if (!bRes)
	{
		bRes = RegisterClass(&wc);
		assert(bRes);
	}

	//2.create window
	DWORD dwStyle = WS_OVERLAPPEDWINDOW;
	RECT rtMainWnd{ 0,0, 720, (int)(720 * 0.618) };
	AdjustWindowRect(&rtMainWnd, dwStyle, 0);
	HWND hWnd = CreateWindow(wc.lpszClassName, L"WN_WINDOWNAEM", dwStyle, 300, 300,
		rtMainWnd.right - rtMainWnd.left, rtMainWnd.bottom - rtMainWnd.top, 0, 0, hInstance, 0);
	assert(hWnd);

	//3.show update
	ShowWindow(hWnd, nShowCmd);
	UpdateWindow(hWnd);

	//4.Msg loop
	MSG msg;
	while (GetMessage(&msg, 0, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	//5.return
	return msg.wParam;
}

LRESULT CALLBACK MyWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	HDC hdc;

	switch (uMsg)
	{
	case WM_LBUTTONDOWN:	//鼠标左键按下后发出
		{
			//测试用
		}break;
	case WM_ERASEBKGND:		// 要重绘时,发出的消息,绘制背景
		{
			//{ //背景纯色
			//	SetClassLong(hWnd, GCL_HBRBACKGROUND, (long)GetStockObject(BLACK_BRUSH)); //设置窗口背景色
			//	InvalidateRect(hWnd, 0, 1);	//重绘
			//}

			{ //背景图片
				HINSTANCE hInst = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE); //得到实例句柄
				assert(hInst);
				HBITMAP hBkgrdBm = (HBITMAP)LoadImageW(hInst, MAKEINTRESOURCE(IDBM_BKGRD), IMAGE_BITMAP, 0, 0, LR_SHARED); //得到背景位图句柄
				assert(hBkgrdBm);
				HBRUSH hBrush = CreatePatternBrush(hBkgrdBm); //创建基于位图的画刷
				assert(hBrush);

				HBRUSH hOldBrush = (HBRUSH)SetClassLong(hWnd, GCL_HBRBACKGROUND, (long)hBrush); //设置窗口背景色
				assert(hOldBrush);

				DeleteObject(hBkgrdBm); //翻译位图
				DeleteObject(hOldBrush); //释放画刷
			}
		}break;
	case WM_CREATE:		//CreateWindow()返回之前发出的消息
		{
			HINSTANCE hInst = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE); //得到实例句柄
			assert(hInst);
			HICON hIcon = (HICON)LoadImageW(hInst, MAKEINTRESOURCE(IDICO_RIGHT), IMAGE_ICON, 0, 0, LR_DEFAULTSIZE);	//得到图标句柄
			assert(hIcon);
			SetClassLong(hWnd, GCL_HICON, (long)hIcon); //设置程序图标
		}break;
	case WM_MOUSEMOVE:		//鼠标在客户区移动时发出
		{
			//得到x在客户区中的坐标
			int x = LOWORD(lParam);		

			//得到当前客户区坐标
			RECT rtClnt{};
			GetClientRect(hWnd, &rtClnt);

			// 区分左右区域
			if (x < rtClnt.right / 2)
			{
				HINSTANCE hInst = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE);	//得到实例句柄
				assert(hInst);
				HCURSOR hCur = (HCURSOR)LoadImageW(hInst, MAKEINTRESOURCE(IDICO_RIGHT), IMAGE_ICON, 0, 0, LR_DEFAULTSIZE);	//得到光标句柄
				assert(hCur);
				SetClassLong(hWnd, GCL_HCURSOR, (long)hCur);	//设置光标
			}
			else
			{
				HINSTANCE hInst = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE);
				assert(hInst);
				HCURSOR hCur = (HCURSOR)LoadImageW(hInst, MAKEINTRESOURCE(IDICO_ERROR), IMAGE_ICON, 0, 0, LR_DEFAULTSIZE);
				assert(hCur);
				SetClassLong(hWnd, GCL_HCURSOR, (long)hCur);
			}
		}break;
	case WM_PAINT:		//绘制客户区时发出
		{
			hdc = BeginPaint(hWnd, &ps);
			Ellipse(hdc, 0, 0, 200, 100);
			EndPaint(hWnd, &ps);
		}break;
	case WM_DESTROY:	//窗口销毁时发出
		{
			PostQuitMessage(0);
		}break;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);	//默认的消息处理
}