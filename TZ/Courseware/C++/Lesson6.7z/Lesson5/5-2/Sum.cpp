#include "Sum.h"


CSum::CSum(int iSum0, int iSum1)
{
	m_iSum0 = iSum0;
	m_iSum1 = iSum1;
}

CSum::~CSum()
{
}

CSum CSum::operator+(const CSum & right)
{
	CSum tmp{0, 0};
	tmp.m_iSum0 = m_iSum0 + right.m_iSum0;
	tmp.m_iSum1 = m_iSum1 + right.m_iSum1;

	return tmp;
}

CSum& CSum::operator+=(const CSum & right)
{
	m_iSum0 += right.m_iSum0;
	m_iSum1 += right.m_iSum1;

	return *this;
}

CSum operator+(const CSum & left, const CSum & right)
{
	CSum tmp{0, 0};
	tmp.m_iSum0 = left.m_iSum0 + right.m_iSum0;
	tmp.m_iSum1 = left.m_iSum1 + right.m_iSum1;

	return tmp;
}
