#pragma once
class CSum
{
	friend CSum operator+(const CSum& left, const CSum& right);		//+��Ԫ����

private:
	int m_iSum0{};
	int m_iSum1{};

public:
	CSum(int iSum0, int iSum1);
	~CSum();

public:
	CSum operator+(const CSum& right);		//+����
	CSum& operator+=(const CSum& right);	//+=����   
};

