class CSum
{
private:
	int m_iSum0{};
	int m_iSum1{};

public:
	CSum(int iSum0, int iSum1);
	~CSum();

	CSum& operator= (const CSum& r);
};


int main()
{
	CSum sum0(1, 1);
	CSum sum1(2, 2);
	
	sum0 = sum1;	//����=
	
	return 0;
}


CSum::CSum(int iSum0, int iSum1)
{
	m_iSum0 = iSum0;
	m_iSum1 = iSum1;
}

CSum::~CSum()
{
}

CSum & CSum::operator=(const CSum & r)
{
	m_iSum0 = r.m_iSum0;
	m_iSum1 = r.m_iSum1;
	return *this;
}
