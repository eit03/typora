#include "Master.h"
#include "House.h"


CMaster::CMaster()
{
}


CMaster::~CMaster()
{
}

int CMaster::GetArea(CHouse & r)
{
	return r.m_iArea;
}

bool CMaster::HasSwimmingPool(CHouse & r)
{
	return r.HasSwimmingPool();
}
