#include "House.h"


bool CHouse::HasSwimmingPool()
{
	return m_bHasSwimmingPool;
}

CHouse::CHouse(int iArea, bool bHasSwimmingPool)
{
	m_iArea = iArea;
	m_bHasSwimmingPool = bHasSwimmingPool;
}

CHouse::~CHouse()
{
}
