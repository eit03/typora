#pragma once

class CHouse;

class CDesign
{
public:
	CDesign();
	~CDesign();

	int GetArea(CHouse& r);
	bool HasSwimmingPool(CHouse& r);
};

