#pragma once


class CHouse;

class CMaster
{
public:
	CMaster();
	~CMaster();

	int GetArea(CHouse& r);
	bool HasSwimmingPool(CHouse& r);
};

