#include "Design.h"
#include "House.h"


CDesign::CDesign()
{
}


CDesign::~CDesign()
{
}

int CDesign::GetArea(CHouse & r)
{
	return r.m_iArea;
}

bool CDesign::HasSwimmingPool(CHouse & r)
{
	return r.HasSwimmingPool();
}
